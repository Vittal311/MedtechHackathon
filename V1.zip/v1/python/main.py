import os
import csv
import json
import time
import atexit
import queue
import datetime
import threading
import numpy as np
from arduino.app_utils import App, Bridge
from edge_impulse_linux.runner import ImpulseRunner

# ===== 路径 / Paths =====
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model.eim")
LOG_PATH = os.path.join(BASE_DIR, "havs_log.csv")        # 每个窗口的日志 / per-window log
STATE_PATH = os.path.join(BASE_DIR, "havs_state.json")   # 当日累计点数 / daily total for restart recovery

# ===== 采样与窗口 / Sampling & window =====
SAMPLE_RATE_HZ = 100
WINDOW_SAMPLES = 100                 # 1 s 窗口 / 1 s window
SLIDE_SAMPLES = 50                   # 0.5 s 步长 / 0.5 s step
STEP_HOURS = (SLIDE_SAMPLES / SAMPLE_RATE_HZ) / 3600.0   # 每个窗口代表的小时数 / hours per window
QUEUE_MAX = 2000                     # 样本队列上限（约 20 s）/ sample queue cap (~20 s)

# ===== HSE 限值 / HSE limits =====
# points = 100 × (A(8)/2.5)² × (T/8) = 2 × a² × T   (a: m/s², T: hours)
EAV_POINTS_LIMIT = 100.0    # 行动值 / Exposure Action Value, A(8) = 2.5 m/s²
ELV_POINTS_LIMIT = 400.0    # 限值 / Exposure Limit Value,   A(8) = 5.0 m/s²
INSTANT_LIMIT_MS2 = 2.5     # 瞬时超限阈值 / instantaneous over-limit threshold

# ===== 模型 / Model =====
IDLE_LABEL = "0_Idle_Safe"
MIN_CONFIDENCE = 0.60
# 类别名以这些前缀开头时视为"极端"，触发 LED 矩阵；请按你模型里的实际标签修改
# Classes whose label starts with these prefixes count as "extreme" and trigger the LED matrix;
# change to match your model's actual labels
EXTREME_PREFIXES = ("3_", "4_")
# 必须与 Edge Impulse 训练时的预处理一致 / MUST match Edge Impulse training preprocessing
MODEL_INPUT_DEMEAN = False

# True：每次运行都把累计点数清零；False：同一天内重启时恢复之前的累计
# True: reset HSE points to 0 on every run; False: restore the day's total after a restart
RESET_ON_START = True

# 启动时让 LED 常亮约 1 秒，用来验证 Bridge → MCU → LED 链路
# Light the LED for ~1 s at startup to verify the Bridge → MCU → LED chain
STARTUP_LED_TEST = True

# ===== 频率计权 Wh / Wh frequency weighting =====
# 注意：分段近似，正式结论前请对照 ISO 5349-1 附录 A 表 A.1 校准
# NOTE: piecewise approximation; verify against ISO 5349-1 Annex A, Table A.1 before formal use
FREQS = np.fft.rfftfreq(WINDOW_SAMPLES, d=1.0 / SAMPLE_RATE_HZ)
_f_safe = np.maximum(FREQS, 1e-9)
WH = np.where(FREQS < 8.0, FREQS / 8.0,
              np.where(FREQS <= 16.0, 1.0, 16.0 / _f_safe))
WH[0] = 0.0


def weighted_hav(dynamic_acc: np.ndarray) -> float:
    """Wh 计权后的三轴合成值 a_hv (m/s²) / Wh-weighted combined 3-axis a_hv (m/s²)"""
    spec = np.fft.rfft(dynamic_acc, axis=0)
    weighted = np.fft.irfft(spec * WH[:, None], n=WINDOW_SAMPLES, axis=0)
    rms_per_axis = np.sqrt(np.mean(weighted ** 2, axis=0))
    return float(np.sqrt(np.sum(rms_per_axis ** 2)))


# ===== 状态 / State =====
state = {"date": "", "points": 0.0}
state_lock = threading.Lock()
last_level = 0
window_count = 0
dropped_samples = 0


def today_str() -> str:
    return datetime.date.today().isoformat()


def level_for(points: float) -> int:
    """0 = 无 / none, 1 = EAV 预警 / warning, 2 = ELV 限值 / limit"""
    if points >= ELV_POINTS_LIMIT:
        return 2
    if points >= EAV_POINTS_LIMIT:
        return 1
    return 0


def save_state():
    # 先写临时文件再替换，防止断电损坏 / temp file + replace to survive power loss
    with state_lock:
        snapshot = dict(state)
    tmp = STATE_PATH + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(snapshot, f)
        os.replace(tmp, STATE_PATH)
    except OSError as e:
        print(f"WARN: could not save state: {e}")


def load_state():
    """恢复当天累计；非今天的数据则从 0 开始 / Restore today's total, else start at 0"""
    global state
    if RESET_ON_START:
        state = {"date": today_str(), "points": 0.0}
        save_state()
        print("HSE points reset to 0 at startup. / 启动时累计点数已清零。")
        return
    try:
        with open(STATE_PATH) as f:
            saved = json.load(f)
        if saved.get("date") == today_str():
            state = {"date": saved["date"], "points": float(saved.get("points", 0.0))}
            print(f"Restored today's exposure: {state['points']:.2f} points / 已恢复当日累计点数")
            return
    except (OSError, ValueError, KeyError):
        pass
    state = {"date": today_str(), "points": 0.0}


def new_day():
    global state, last_level
    with state_lock:
        state = {"date": today_str(), "points": 0.0}
    last_level = 0
    save_state()
    print("New day: exposure reset. / 新的一天，累计点数已重置。")


# ===== 日志（保持文件打开）/ Logging (file kept open) =====
log_file = None
log_writer = None


def init_log():
    global log_file, log_writer
    new_file = not os.path.exists(LOG_PATH)
    log_file = open(LOG_PATH, "a", newline="")
    log_writer = csv.writer(log_file)
    if new_file:
        log_writer.writerow(["timestamp", "tool", "confidence", "a_hv_ms2", "points", "alert_level"])
        log_file.flush()


def append_log(tool, confidence, a_hv, points, level):
    log_writer.writerow([
        datetime.datetime.now().isoformat(timespec="seconds"),
        tool, f"{confidence:.2f}", f"{a_hv:.3f}", f"{points:.2f}", level,
    ])
    log_file.flush()


# ===== Bridge 安全调用 / Safe Bridge call =====
def safe_notify(name, *args):
    try:
        Bridge.notify(name, *args)
    except Exception as e:
        print(f"WARN: Bridge.notify({name}) failed: {e}")


# ===== 模型 / Model =====
try:
    os.chmod(MODEL_PATH, 0o755)
except OSError:
    pass   # 只读文件系统也没关系 / fine on read-only filesystems

runner = ImpulseRunner(MODEL_PATH)
model_info = runner.init()
print(f"Loaded Edge Impulse model: {model_info['project']['name']} / 已加载模型")

# 校验输入长度，避免窗口配置与模型不匹配 / validate input size against the model
_expected = model_info.get("model_parameters", {}).get("input_features_count")
if _expected is not None and _expected != WINDOW_SAMPLES * 3:
    raise RuntimeError(
        f"Model expects {_expected} features but window gives {WINDOW_SAMPLES * 3} "
        f"(check WINDOW_SAMPLES / axes). / 模型输入长度与窗口不一致"
    )


# ===== 处理一个窗口 / Process one window =====
def process_window(window: np.ndarray):
    global last_level, window_count

    if state["date"] != today_str():
        new_day()

    dynamic_acc = window - np.mean(window, axis=0)
    a_hv = weighted_hav(dynamic_acc)
    if not np.isfinite(a_hv):
        return

    # 调试：确认原始数据是否真的在变化（确认正常后可删除）
    # Debug: confirm the raw data actually varies (remove once it looks right)
    print(f"raw mean={window.mean(axis=0).round(3)} std={window.std(axis=0).round(4)}")

    # 先通知瞬时超限，不必等模型推理 / notify instant over-limit first, before inference
    safe_notify("set_instant", 1 if a_hv > INSTANT_LIMIT_MS2 else 0)

    top_class, confidence = IDLE_LABEL, 0.0
    try:
        model_input = dynamic_acc if MODEL_INPUT_DEMEAN else window
        res = runner.classify(model_input.flatten().tolist())
        scores = res["result"]["classification"]
        top_class = max(scores, key=scores.get)
        confidence = scores[top_class]
    except Exception as e:
        print(f"WARN: classification failed, window not counted: {e}")

    if top_class != IDLE_LABEL and confidence > MIN_CONFIDENCE:
        with state_lock:
            state["points"] += 2.0 * (a_hv ** 2) * STEP_HOURS

    # 类别 3 / 4（极端）：通知 MCU 点亮 LED 矩阵（MCU 自行保持约 3 秒）
    # Class 3 / 4 (extreme): tell the MCU to light the LED matrix (MCU holds it for ~3 s)
    if top_class.startswith(EXTREME_PREFIXES) and confidence > MIN_CONFIDENCE:
        print(f"EXTREME tool detected: {top_class} / 检测到极端工具")
        safe_notify("set_extreme", 1)

    with state_lock:
        points = state["points"]
    level = level_for(points)

    if level != last_level:
        if level == 1:
            print("WARNING: EAV reached (100 points). / 已达到行动值 EAV（100 点）！")
        elif level == 2:
            print("STOP: ELV reached (400 points). / 已达到限值 ELV（400 点），禁止继续使用！")
        last_level = level
        save_state()   # 等级变化立刻保存 / save immediately on level change

    # 每个窗口重发等级，MCU 重启后自动同步 / resend every window so the MCU resyncs after restart
    safe_notify("set_alert", level)

    print(
        f"Tool: {top_class} ({confidence:.0%}) | a_hv: {a_hv:.2f} m/s^2 | "
        f"HSE Points: {points:.2f} / {EAV_POINTS_LIMIT:.0f} (EAV) / {ELV_POINTS_LIMIT:.0f} (ELV)"
    )
    append_log(top_class, confidence, a_hv, points, level)

    window_count += 1
    if window_count % 10 == 0:
        save_state()


# ===== 工作线程：回调只入队，推理在这里做 =====
# ===== Worker thread: the callback only enqueues, inference happens here =====
sample_queue = queue.Queue(maxsize=QUEUE_MAX)
stop_event = threading.Event()


def worker():
    global dropped_samples
    buffer = []
    last_drop_report = 0
    while not stop_event.is_set():
        try:
            sample = sample_queue.get(timeout=0.5)
        except queue.Empty:
            continue
        buffer.append(sample)
        if len(buffer) < WINDOW_SAMPLES:
            continue

        window = np.array(buffer[:WINDOW_SAMPLES], dtype=np.float32)
        del buffer[:SLIDE_SAMPLES]
        try:
            process_window(window)
        except Exception as e:
            print(f"ERROR in process_window: {e}")

        if dropped_samples != last_drop_report:
            print(f"WARN: {dropped_samples} samples dropped (processing too slow). / 处理过慢，已丢样本")
            last_drop_report = dropped_samples


def on_imu_sample(ax: float, ay: float, az: float):
    """Bridge 回调：必须尽快返回，否则会阻塞 100 Hz 数据流
    Bridge callback: must return fast or it will stall the 100 Hz stream"""
    global dropped_samples
    try:
        sample_queue.put_nowait((ax, ay, az))
    except queue.Full:
        dropped_samples += 1


def shutdown():
    stop_event.set()
    save_state()
    try:
        if log_file:
            log_file.close()
    except OSError:
        pass


# ===== 启动 / Startup =====
load_state()
init_log()
last_level = level_for(state["points"])
atexit.register(shutdown)

threading.Thread(target=worker, daemon=True).start()
Bridge.provide("imu_sample", on_imu_sample)

if STARTUP_LED_TEST:
    safe_notify("set_instant", 1)   # LED 常亮 1 s / LED solid for 1 s (INSTANT_HOLD_MS on MCU)


def loop():
    time.sleep(0.05)


App.run(user_loop=loop)