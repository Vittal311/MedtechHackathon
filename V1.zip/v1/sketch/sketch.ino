#include <Arduino_RouterBridge.h>
#include <Modulino.h>
#include <Arduino_LED_Matrix.h>

// ===== 硬件 / Hardware =====
ModulinoMovement imu;   // Modulino Movement (ABX00101)

// Qwiic 接口使用的 I2C 总线。UNO Q 上通常是 Wire1；如果读数全是 0，两个都试一下。
// I2C bus used by the Qwiic connector. Usually Wire1 on UNO Q; if readings are all 0, try both.
#define MODULINO_WIRE Wire1

// 报警 LED：UNO Q MCU 侧板载 LED（请对照官方引脚图确认）
// Alarm LED: onboard MCU-side LED on UNO Q (confirm against the official pinout)
const int ALARM_LED_PIN = LED_BUILTIN;

// UNO Q 的板载 LED 通常是低电平点亮；如果现象相反就改成 false
// UNO Q onboard LEDs are usually active-LOW; set to false if it behaves inverted
const bool LED_ACTIVE_LOW = true;

inline void writeLed(bool on) {
  digitalWrite(ALARM_LED_PIN, (on != LED_ACTIVE_LOW) ? HIGH : LOW);
}

// 静音确认按钮，接 D2，按下接地 / Acknowledge button on D2, active-LOW
const int ACK_BUTTON_PIN = 2;

// ===== 采样参数 / Sampling =====
const unsigned long SAMPLE_INTERVAL_MS = 10;   // 100 Hz，须与 Edge Impulse 一致 / must match Edge Impulse
const float G_TO_MS2 = 9.80665f;
unsigned long lastSampleMs = 0;
unsigned long sampleCount = 0;                 // 调试用 / for debugging

// ===== 累计点数报警 / Cumulative exposure alarm =====
// 0 = 无, 1 = EAV 预警 (100 点), 2 = ELV 限值 (400 点)
volatile int alertLevel = 0;
int acknowledgedLevel = 0;

// ===== 瞬时超限 / Instantaneous over-limit =====
const unsigned long INSTANT_HOLD_MS = 1000;
volatile unsigned long instantOverUntilMs = 0;

// ===== LED 闪烁 / Blink =====
const unsigned long BLINK_LEVEL1_MS = 500;   // 预警慢闪 / slow
const unsigned long BLINK_LEVEL2_MS = 150;   // 限值快闪 / fast
unsigned long lastBlinkMs = 0;
bool ledState = false;

unsigned long lastAckPressMs = 0;

// ===== Bridge 回调 / Bridge callbacks =====
void set_alert(int level) {
  if (level < 0) level = 0;
  if (level > 2) level = 2;
  if (level < acknowledgedLevel) acknowledgedLevel = level;

  if (level != alertLevel) {   // 只在变化时打印 / print only on change
    Monitor.print("set_alert: "); Monitor.println(level);
  }
  alertLevel = level;
}

void set_instant(int over) {
  if (over > 0) {
    instantOverUntilMs = millis() + INSTANT_HOLD_MS;
    Monitor.println("set_instant: 1");
  }
}

// ===== LED 矩阵：极端工具提示 / LED matrix: extreme-tool indicator =====
// UNO Q 的矩阵为 8 行 × 13 列 / the UNO Q matrix is 8 rows x 13 columns
ArduinoLEDMatrix matrix;
const int MATRIX_ROWS = 8;
const int MATRIX_COLS = 13;
const unsigned long EXTREME_HOLD_MS = 3000;     // 显示时长 / display duration
const unsigned long EXTREME_FLASH_MS = 250;     // 图案切换间隔 / frame toggle interval

uint8_t frameA[MATRIX_ROWS * MATRIX_COLS];      // 边框 + X / border + X
uint8_t frameB[MATRIX_ROWS * MATRIX_COLS];      // 反色 / inverse
volatile unsigned long extremeUntilMs = 0;
int matrixShown = -1;                           // -1 = 熄灭, 0 = A, 1 = B / -1 = off, 0 = A, 1 = B
unsigned long lastMatrixToggleMs = 0;
int matrixPhase = 0;

void buildFrames() {
  for (int r = 0; r < MATRIX_ROWS; r++) {
    for (int c = 0; c < MATRIX_COLS; c++) {
      bool border = (r == 0 || r == MATRIX_ROWS - 1 || c == 0 || c == MATRIX_COLS - 1);
      int d = (r * (MATRIX_COLS - 1)) / (MATRIX_ROWS - 1);   // 对角线 / diagonal
      bool diag = (c == d) || (c == (MATRIX_COLS - 1) - d);
      uint8_t on = (border || diag) ? 1 : 0;
      frameA[r * MATRIX_COLS + c] = on;
      frameB[r * MATRIX_COLS + c] = on ? 0 : 1;
    }
  }
}

// Python 检测到类别 3 或 4 时调用 / called by Python when class 3 or 4 is detected
void set_extreme(int on) {
  if (on > 0) {
    if (extremeUntilMs <= millis()) Monitor.println("set_extreme: 1");
    extremeUntilMs = millis() + EXTREME_HOLD_MS;
  }
}

void updateMatrix(unsigned long now) {
  if (extremeUntilMs > now) {
    if (matrixShown == -1 || now - lastMatrixToggleMs >= EXTREME_FLASH_MS) {
      lastMatrixToggleMs = now;
      matrixPhase = 1 - matrixPhase;
      matrix.draw(matrixPhase == 0 ? frameA : frameB);
      matrixShown = matrixPhase;
    }
  } else if (matrixShown != -1) {
    matrix.clear();
    matrixShown = -1;
  }
}

void setup() {
  Bridge.begin();
  Monitor.begin();

  pinMode(ALARM_LED_PIN, OUTPUT);
  writeLed(false);

  // LED 自检：闪 3 次。如果看不到，说明引脚或极性不对
  // LED self-test: 3 blinks. If you don't see them, the pin or polarity is wrong
  for (int i = 0; i < 3; i++) {
    writeLed(true);  delay(250);
    writeLed(false); delay(250);
  }

  Modulino.begin(MODULINO_WIRE);
  if (!imu.begin()) {
    Monitor.println("ERROR: Modulino Movement (ABX00101) not detected! / 未检测到 IMU！");
  } else {
    Monitor.println("IMU detected. / 已检测到 IMU。");
  }

  pinMode(ACK_BUTTON_PIN, INPUT_PULLUP);

  Bridge.provide_safe("set_alert", set_alert);
  Bridge.provide_safe("set_instant", set_instant);
  Bridge.provide_safe("set_extreme", set_extreme);

  buildFrames();
  matrix.begin();
  matrix.setGrayscaleBits(1);   // 1 位：每个点只有亮 / 灭 / 1-bit: each pixel on or off
  matrix.clear();
  Monitor.println("MCU 100 Hz IMU streamer ready. / MCU 100 Hz IMU 流程序已就绪。");

  lastSampleMs = millis();
}

// 按钮（200 ms 防抖）/ Button with 200 ms debounce
void handleAckButton(unsigned long now) {
  if (digitalRead(ACK_BUTTON_PIN) == LOW && now - lastAckPressMs > 200) {
    lastAckPressMs = now;
    acknowledgedLevel = alertLevel;
    Monitor.println("Alarm acknowledged. / 报警已确认。");
  }
}

// 优先级：瞬时超限（常亮）> 累计等级（闪烁 / 常亮 / 熄灭）
// Priority: instantaneous over-limit (solid) > cumulative level (blink / solid / off)
void updateAlarmLed(unsigned long now) {
  if (instantOverUntilMs > now) {
    if (!ledState) { ledState = true; writeLed(true); }
    return;
  }

  if (alertLevel == 0) {
    if (ledState) { ledState = false; writeLed(false); }
    return;
  }

  if (alertLevel <= acknowledgedLevel) {
    if (!ledState) { ledState = true; writeLed(true); }
    return;
  }

  unsigned long halfPeriod = (alertLevel == 2) ? BLINK_LEVEL2_MS : BLINK_LEVEL1_MS;
  if (now - lastBlinkMs >= halfPeriod) {
    lastBlinkMs = now;
    ledState = !ledState;
    writeLed(ledState);
  }
}

void loop() {
  unsigned long now = millis();

  // 1. 100 Hz 采样 / 100 Hz sampling
  if (now - lastSampleMs >= SAMPLE_INTERVAL_MS) {
    lastSampleMs += SAMPLE_INTERVAL_MS;
    if (now - lastSampleMs > 10 * SAMPLE_INTERVAL_MS) lastSampleMs = now;

    // 只发送新数据；update() 返回 false 说明没有新样本
    // Only send fresh data; update() returning false means no new sample
    // 如果编译报错（update() 无返回值），把 if 改成 imu.update(); 即可
    // If this fails to compile (update() returns void), change the if to a plain imu.update();
    if (imu.update()) {
      float ax = imu.getX() * G_TO_MS2;
      float ay = imu.getY() * G_TO_MS2;
      float az = imu.getZ() * G_TO_MS2;

      Bridge.notify("imu_sample", ax, ay, az);

      // 每秒打印一次原始值，用来确认 IMU 真的在变化
      // Print raw values once a second to confirm the IMU values actually change
      if (++sampleCount % 100 == 0) {
        Monitor.print("IMU m/s2: ");
        Monitor.print(ax); Monitor.print(", ");
        Monitor.print(ay); Monitor.print(", ");
        Monitor.println(az);
      }
    }
  }

  // 2. 确认按钮 / Acknowledge button
  handleAckButton(now);

  // 3. LED 报警 / LED alarm
  updateAlarmLed(now);

  // 4. LED 矩阵（极端工具）/ LED matrix (extreme tool)
  updateMatrix(now);
}